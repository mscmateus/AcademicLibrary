DROP TABLE IF EXISTS `#__al_docentes`;
DROP TABLE IF EXISTS `#__al_discentes`;
DROP TABLE IF EXISTS `#__al_categorias`;
DROP TABLE IF EXISTS `#__al_trabalhos`;
DROP TABLE IF EXISTS `#__al_banca`;
DROP TABLE IF EXISTS `#__al_autoria`;
DROP TABLE IF EXISTS `#__al_orientacao`;